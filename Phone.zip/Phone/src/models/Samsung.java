package models;

public class Samsung extends Phone{
    public Samsung() {
    }
    public Samsung(String number, String model) {
        super(number, model);
    }
    public Samsung(String number, String model, double weight) {
        super(number, model, weight);
    }
}
