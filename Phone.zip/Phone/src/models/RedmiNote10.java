package models;

public class RedmiNote10 extends Phone {
    public RedmiNote10() {
    }
    public RedmiNote10(String number, String model) {
        super(number, model);
    }
    public RedmiNote10(String number, String model, double weight) {
        super(number, model, weight);
    }
}
