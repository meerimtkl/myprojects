import models.Iphone;
import models.Phone;
import models.RedmiNote10;
import models.Samsung;

public class Main {
    public static void main(String[] args) {
        Phone redmiNote10 = new RedmiNote10("0557344234", "Samsung Galaxy A52 ", 189);
        Phone iphone = new Iphone("2323525", "Redmi Note 10 Pro", 192);
        Phone samsung1 = new Samsung("234567", "iPhone 13 Pro", 204);

        System.out.println(redmiNote10.getModel() + " " + redmiNote10.getNumber() + " " + redmiNote10.getWeight());
        System.out.println(iphone.getModel() + " " + iphone.getNumber() + " " + iphone.getWeight());
        System.out.println(samsung1.getModel() + " " + samsung1.getNumber() + " " + samsung1.getWeight());

        redmiNote10.receiveCall("DAD");
        iphone.receiveCall("MOM");
        samsung1.receiveCall("Brother");

        Phone phone=new Phone();
        phone.sendMessage("13424442","21324124");

    }
}
